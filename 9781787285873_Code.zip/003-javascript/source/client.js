import React from 'react';
import ReactDOM from 'react-dom';
import App from './app';
import {Map} from 'immutable';

/*
callBack((a,b) => {
	//this
});

let a = new Array(50),
		i;



for(i=0; i<50; i++){
	a[i] = i;
}
console.log(a);
a.length = 20;

 for(i=0; i<20; i++){
	a[i] = i;
}


console.log(a);
*/

const date = new Date(),
			map1 = Map({a:1,b:date,c:3}),
			map2 = map1.set('b',100),
			map3 = map2.set('b',date);


console.log(map1.equals(map3))


ReactDOM.render(<App />,document.getElementById('react'));

