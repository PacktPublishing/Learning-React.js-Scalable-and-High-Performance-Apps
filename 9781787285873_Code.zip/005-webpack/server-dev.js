const webpack = require('webpack'),
			config = require('./webpack.config');
			config.devtool = 'eval';
			config.entry.unshift('webpack/hot/dev-server','webpack-hot-middleware/client');
			config.output.path = "/";
			config.plugins.unshift(
					new webpack.HotModuleReplacementPlugin(),
					new webpack.NoErrorsPlugin()
				);

const compiler = webpack(config),
			server = require('./source/server'),
			app = server.getApp();
			app.use(require("webpack-dev-middleware")(compiler,{
				noInfo:true
			}));

			app.use(require("webpack-hot-middleware")(compiler));

			server.build(3010);



