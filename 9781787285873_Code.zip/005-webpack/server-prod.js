process.env.NODE_ENV = 'production';
require('./source/server').build(3000);