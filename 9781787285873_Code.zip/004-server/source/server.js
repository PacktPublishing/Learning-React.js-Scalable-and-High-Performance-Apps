require('babel-register');

global.server = true;

const React = require('react');
const ReactDOMServer = require('react-dom/server');
const express = require('express');


module.exports = {
		build: (PORT) =>{
			const app = express();
			app.use(express.static('public'));
			app.set('view engine','ejs');

			app.route('/')
			.get((req,res)=>{


				res.render('layout/blank',{title:'Mastering React.js Perfomance', body:
												ReactDOMServer.renderToString(
													React.createElement(require('./app').default)
												)
			});
			})

			app.listen(3000,()=>{
				console.log('Our server is running on port 3000');
			});
			
			return app;
		}
};








